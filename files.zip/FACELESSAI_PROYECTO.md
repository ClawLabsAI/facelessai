# FacelessAI — Documento de Contexto del Proyecto
**Última actualización:** Marzo 2026  
**Versión actual del dashboard:** v3.8  
**URL live:** https://clawlabsai.github.io/facelessai  
**Repositorio:** https://github.com/clawlabsai/facelessai  
**Rama:** main | Archivos: index.html · keys.html

---

## Objetivo del proyecto

Plataforma web para automatizar la creación y publicación de contenido faceless en YouTube Shorts, TikTok e Instagram Reels. Uso personal para monetizar canales propios. A futuro: SaaS.

---

## Arquitectura actual

- HTML/CSS/JS puro — un solo archivo index.html
- Desplegado en GitHub Pages (gratis)
- URL: clawlabsai.github.io/facelessai

## Almacenamiento localStorage

- fai_key_anthropic — API key Anthropic
- fai_key_openai — API key OpenAI  
- fai_key_pexels — API key Pexels
- fai_key_elevenlabs — API key ElevenLabs (opcional)
- fai_key_github — GitHub token para deploy
- fai_drafts — Array JSON de borradores
- fai_channels — Array JSON de canales creados
- fai_lang / fai_gender — Idioma y voz activos
- fai_tier — Tier de coste activo
- fai_theme / fai_currency / fai_date_fmt — Preferencias UI

---

## APIs conectadas y funcionando

- Anthropic Claude — Ideas, Score, Scripts, Descubrimiento canales (~$0.003/script)
- OpenAI TTS — Voz MP3 real (~$0.006/audio)
- Pexels — Clips de vídeo gratuitos ($0)

---

## Archivos del proyecto

- index.html — Dashboard principal v3.8
- keys.html — Página auxiliar para API keys
- FACELESSAI_PROYECTO.md — Este documento
- .github/workflows/sync-gist.yml — GitHub Action sync

## Gist de GitHub
- ID: 86bf7d5a8e7dc233a62a99debcfae390
- Secrets repo: GIST_ID + GIST_TOKEN

---

## API Keys configuradas

- Anthropic: ACTIVA (sk-ant-api03-... 108 chars)
- OpenAI: ACTIVA (sk-proj-... 164 chars)
- Pexels: ACTIVA
- ElevenLabs: Opcional (tier Premium)
- GitHub Token: ACTIVO (ghp_...)

---

## Sistema de idiomas y voces (topbar)

- Español España -> voz onyx (hombre) / nova (mujer)
- English US -> voz echo (hombre) / alloy (mujer)
- Español Latino -> voz fable (hombre) / shimmer (mujer)

Afecta a: prompts Claude, voz TTS, hashtags, horarios recomendados

---

## Tiers de coste

- GRATIS: Llama local + Kokoro — $0.00/video
- ECONOMICO: Claude Haiku + OpenAI TTS-1 — ~$0.01/video
- OPTIMIZADO: Claude Sonnet + OpenAI TTS-1 HD — ~$0.06/video
- PREMIUM: Claude Opus + ElevenLabs v3 — ~$0.25/video

---

## Menu sidebar

- Inicio: Dashboard, Canales, Borradores
- Crear: Tendencias, Score IA, Pipeline, URL a Video
- Biblioteca: Plantillas, Clonar canal, Reutilizar
- Automatizacion: AutoPilot, Modelos IA, Presupuesto
- Datos: Monetizacion, Configuracion

---

## Topbar v3.8 (limpia)

[ES] [EN] [LAT]  [Hombre] [Mujer]  [Manual] [AutoPilot]  ...  [presupuesto]  [deploy icono]  [Generar]

---

## Funciona al 100% real

1. Ideas reales con Claude por nicho e idioma
2. Score en pipeline — Claude analiza la idea seleccionada automaticamente
3. Scripts reales — Claude adapta al idioma/mercado
4. Audio MP3 real — OpenAI TTS con voz segun idioma+genero
5. Clips Pexels — busqueda real con miniaturas
6. Borradores reales — localStorage con audio, script, score, idioma
7. Canales — creacion y guardado en localStorage
8. Descubrimiento IA — Claude sugiere 6 canales con score, CPM, saturacion, ROI
9. Configuracion — keys visibles correctamente
10. Preferencias — tema, idioma UI, moneda, formato fecha (persistentes)

---

## Configuracion — secciones

1. API Keys — Anthropic, OpenAI, Pexels, ElevenLabs con test y diagnostico
2. Tiers de coste — selector + estimador mensual
3. Preferencias generales — Tema, Idioma UI, Moneda, Formato fecha

---

## Proximos pasos

### Paso 1 — Backend MP4 en Railway (SIGUIENTE)
Python + FastAPI + FFmpeg
Input: audio MP3 + clips Pexels + script
Output: MP4 1080x1920 descargable
Coste: gratis en Railway plan hobby

### Paso 2 — YouTube API
Publicar directamente desde el dashboard
Requiere: Google Cloud Console + OAuth

### Paso 3 — AutoPilot real
Cron job en Railway ejecutando el pipeline completo automaticamente

### Paso 4 — TikTok + Instagram APIs
Cross-posting automatico

---

## Changelog

- v3.0 — APIs reales conectadas (Claude + OpenAI + Pexels)
- v3.1 — Fix localStorage, version visible
- v3.2 — Fix KEYS declaradas antes de funciones
- v3.3 — Audio player real en aprobacion, sin auto-advance
- v3.4 — Menu sidebar reorganizado sin numeros
- v3.5 — Selector idioma/voz topbar, modal canal, descubrimiento IA
- v3.6 — Borradores reales, score pipeline auto, canales guardados
- v3.7 — Preferencias generales en Configuracion
- v3.8 — Topbar limpia sin elementos redundantes

---

## Como continuar desde otro PC

1. Ir a claude.ai con tu cuenta — este chat esta guardado
2. O pegar este documento en una conversacion nueva
3. Abrir clawlabsai.github.io/facelessai/keys.html
4. Introducir las API keys de nuevo
5. Continuar

Actualizado con cada version del dashboard.
